
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'pharmswap',
  applicationName: 'pharm-backend',
  appUid: 'xK6Pp3Dnc2fTtzRL9g',
  orgUid: '4805af2a-c936-4cd6-bf7c-bd3bc94731b7',
  deploymentUid: '99769c40-ce3b-4a7a-8d6d-b9c7eabd4ca6',
  serviceName: 'pharm-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'pharm-api-dev-getCirculatingSupply', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getCirculatingSupply, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}